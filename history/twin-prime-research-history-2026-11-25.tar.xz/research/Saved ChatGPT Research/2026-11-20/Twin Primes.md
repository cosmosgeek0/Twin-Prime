# Twin Primes

**Status.** No complete proof or disproof is ready to check or claim. The exact goal is to prove that infinitely many primes $P$ have $P+2$ prime, or to prove that only finitely many do. This is the single working handoff and will be updated in place. The owner has resumed research; no background execution is implied.

**Best surviving result.** Let $T_X$ be the normalized weighted count of twin primes on $(X,2X]$. Let $Q_X$ count, in the same units and with the weight defined below, primes $P$ for which $P+2$ is squarefree and has exactly two or three prime factors, each larger than $X^{1/21}$. The internally checked argument in §308LU gives

$$
3.04808378 < \liminf_{X\to\infty}(T_X+Q_X)
\le \limsup_{X\to\infty}(T_X+Q_X)<4.495735.
$$

**Next decisive test.** Prove $\liminf Q_X\le 3.04808$ on the **actual shifted primes**, or prove $\liminf R_X\le 0.21805$ for the signed composite-pair reduction below. A new one-sided calculation isolates the only positive rank-three contribution on the $M=N-2$ side; it is described under “Latest checked calculation.” **The estimate that would settle the problem is $\liminf Q_X\le 3.04808$ on the actual shifted primes.** Along a sequence approaching that upper bound for $Q_X$, the strict difference between $3.04808378$ and $3.04808$ forces $T_X>0$ on arbitrarily large intervals. If there are only finitely many twins, $T_X=0$ on every sufficiently large interval. The present estimates allow that possibility.

## The measures and weights

Write $J_X=\int_X^{2X}dt/\log t$, $K_0=2C_2=2\prod_{\ell>2,\ \ell\ {\rm prime}}(1-1/(\ell-1)^2)$, and $B_X=K_0J_X$. Here $\omega(n)$ counts distinct prime factors, $P^-(n)$ is the least prime factor, $\mu$ is the Möbius function, and $v_+=\max(v,0)$. For squarefree $N$, put

$$
G_2(N)=\sum_{d\mid N}\mu(d)\left(1-2\frac{\log d}{\log N}\right)_+^2,\qquad
\mathcal A_X=\{N:\ N\text{ squarefree},\ \omega(N)\in\{2,3\},\ P^-(N)>X^{1/21}\}.
$$

Both sums below run over **primes** $X<P\le 2X$. The twin has coefficient one before the common logarithmic weight.

$$
T_X=\frac{1}{B_X}\sum_{P:\ P+2\ {\rm prime}}\log P,\qquad
Q_X=\frac{1}{B_X}\sum_{P:\ P+2\in\mathcal A_X}(\log P)\,G_2(P+2).
$$

The archive often writes $T$ for this normalized quantity and $T_X$ for the *unnormalized* count. On a semiprime with prime log shares $x,1-x$, $G_2=4x(1-x)$. On three prime factors it is also nonnegative. The ordinary angular comparison integrates over the normalized prime-factor logarithms with harmonic weights on their sum-one simplex. For $\mathcal A_X$ it gives a value in $(2.68265017,2.68270588)$. It leaves open how often the corresponding products $N$ have $N-2$ prime.

## A signed sum on adjacent composites

Take every $M\in(X,2X]$ that is squarefree, has $2\le\omega(M)\le7$, and has $P^-(M)>X^{1/20}$. Set $N=M+2$ and retain exactly $N\in\mathcal A_X$. With $D=X^{0.24995}$, define

$$
R_X=\frac{1}{B_X}\sum_{M,N\ {\rm as\ above}}G_2(N)
  \sum_{\substack{k\mid M\\1<k<M/D}}\mu(M/k)\log k .
$$

The logarithm in this sum is $\log k$. Every divisor satisfying the strict window contributes, including those giving negative terms. The reduction starts with $\Lambda(M)=\sum_{d\mid M}\mu(d)\log(M/d)$. After the least-prime cutoff, split at $d=D$ and use $k=M/d$ on $d>D$. A prime $M$ contributes zero to the long part. Sections 308LR–LT bound the full short part from above by $2.699339567$ in the limiting normalization, and the positive contribution of all omitted $M$-ranks at least eight by $0.130688530$. Repeated polynomial-size prime bases are controlled separately. In particular,

$$
\limsup_{X\to\infty}(Q_X-R_X)\le 2.699339567+0.130688530.
$$

It therefore suffices to prove **$\liminf R_X\le 0.21805$**. Finite twins would force $\liminf R_X>0.21805568$. The independent product of the two ordinary angular measures gives a value between $0.01336$ and $0.04107$ for this exact test. Multiplying that measure by $1-(-1)^{\omega(N)+\omega(M)}$ instead gives a value above $0.93847$. Thus finite twins would require an excess above the independent comparison greater than $0.17698$. To exclude it requires a one-sided estimate for the **joint arithmetic sum at shift two**. Replacing the signed kernel by its absolute value discards cancellation at a scale larger than the available margin.

## How the physical bound was obtained

1. **Retain all ranks before taking the complement.** For $N=P+2$, the full quadratic divisor sum has normalized total $4+o(1)$ in the recorded reduction. Complementary divisors make every even rank at least four vanish. Rank five is nonpositive. For each odd rank at least seven, take the three smallest genuine prime log shares. Their third finite difference of $4(1/2-y)_+^2$ is eight times the convolution of three interval indicators evaluated at $1/2-y$. In a positive term of the remaining expansion, the two groups of remaining shares both have even size. Both are nonempty because the smallest three shares sum to less than $1/2$. Integrating the two group densities bounds the *ordinary positive mass* of the whole high-rank contribution by $0.042218021$. The applicable $10/3$ upper sieve comparison and the signed mass of those ranks then bound the physical low ranks. See §§308LD, 308LO and 308LT.

2. **Subtract the small-factor contribution in the correct direction.** Let $S_X$ be the rank-two and rank-three contribution with least factor at most $X^{1/21}$, in the same units as $Q_X$. The full low-rank sum $L_X$ is $T_X+Q_X+S_X+o(1)$. Section 308LT gives $\liminf L_X>3.85927326$ and $\limsup L_X<4.566242252$. Section 308LU gives $\limsup S_X<0.811189477$ and $\liminf S_X>0.07050782$. The upper bound on $S_X$ yields the lower bound on $T_X+Q_X$. The lower bound on $S_X$ yields the upper bound on $T_X+Q_X$.

3. **Keep the two savings disjoint.** For a true small prime $q\mid N$, write $t=\log q/\log N$ and $V=N/q$. A conditional quadratic majorant first bounds $S_X$ by $0.823707720677$ in limsup. Two distinct small primes can charge the same $N$ twice. Counting their ordered log shares and preserving the actual residual ranks saves more than $0.00625460463$. A further saving greater than $0.00626363930772$ comes from $V$ prime or $V$ a semiprime whose smaller relative share exceeds $0.45$. The upper sieve here acts on $qV-2$ with $q$ a genuine short prime in the product source. The residual on the two-small-prime family has least share below $0.05$. These are the two savings used in the displayed upper for $S_X$.

4. **Obtain the opposite bound on $S_X$ from a positive subfamily.** Require every prime factor of $V$ to exceed $V^{0.105}$ and let $s_i$ be its prime log shares with multiplicity. The score $1-\sum_i(1-3s_i)_+$ is one on a prime, is $\min(1,3\min_i s_i)$ on a semiprime, and is nonpositive at ranks at least four. Section 308LU subtracts its positive part on triples. On each successful row $q$ is the unique small prime. A direct sieve at relative level $0.49995$ and a switched upper sieve at full $X$-level $0.5999$ give the stated lower for $S_X$. The two levels apply to different source sequences. The larger level requires the genuine short prime factor in the switched application.

## Latest checked calculation — exact positive three-prime sector (19 November 2026)

**Proved elementary factorization lemma, with an independent numeric consistency test but no external review.** Let $M$ be squarefree with two or three distinct prime factors and define the *actual* logarithmic long-divisor weight occurring in $R_X$:

$$
F_D(M)=\sum_{\substack{k\mid M\\1<k<M/D}}\mu(M/k)\log k,
\qquad D=X^{0.24995}.
$$

For any squarefree $M$ having at least two prime factors, Möbius cancellation gives the **exact finite identity**

$$
F_D(M)=-\sum_{\substack{d\mid M\\d\le D}}\mu(d)\log(M/d).
\tag{A}
$$

Indeed the complete divisor sum on the right before truncation equals $(\mu*\log)(M)=\Lambda(M)=0$ when $M$ is composite but squarefree with rank at least two, and $d=M$ contributes $\log1=0$. This identity includes $d=1$; neglecting its $-\log M$ contribution reverses the apparent signs.

For $M=rs$ with $r<s$ primes, $M\in(X,2X]$, the two possible formulas are

$$
F_D(rs)=\begin{cases}-\log r,&r\le D,\\-\log(rs),&r>D.\end{cases}
$$

Thus **every squarefree two-prime $M$ has strictly negative weight**. For $M=rsp$ with primes $r<s<p$, $M\in(X,2X]$, at most two prime factors can lie below $D$, because $D^3=X^{0.74985}<M$. The exhaustive formula is

$$
F_D(rsp)=\begin{cases}
-\log(rsp),&r>D,\\
-\log r,&r\le D<s,\\
0,&r<s\le D,\ rs\le D,\\
+\log p,&r<s\le D,\ rs>D.
\end{cases}
\tag{B}
$$

In particular, the **only positive rank-three sector** is the disjoint true-prime family

$$
X^{1/20}<r<s\le X^{0.24995},\qquad rs>X^{0.24995},
\qquad p> X^{0.50010},\qquad M=rsp.
\tag{C}
$$

The last bound follows from $rs\le D^2=X^{0.49990}$ and $M>X$, so $p>X^{0.50010}$. This remains true when the $M$ squarefree gate and all of the $N=M+2$ conditions from $R_X$ are imposed. It explicitly identifies a genuine prime $p$, **not** an auxiliary convolution integer. Any one-sided upper for $R_X$ may discard the negative rank-two sector, but must retain (C) and all positive contributions from the still-unresolved ranks four through seven. The $N$ factor gate and $G_2(N)$ weight are *not* removed by this identity.

**An unconditional one-sided numerical benchmark (without the $N=M+2$ test).** Let $\mathcal C_X$ consist of the triples in (C) with $X<M\le2X$. Then

$$
\sum_{M\in\mathcal C_X}\log P^+(M)
=\bigl(\mathcal I+o(1)\bigr)X,
\qquad \mathcal I=\frac12\int_{\delta}^{t}\int_{\max(\delta,t-u)}^{t}\frac{dv\,du}{uv},
\quad \delta=\frac1{20},\quad t=0.24995.
\tag{D}
$$

This is a theorem from the ordinary prime number theorem and Mertens' prime harmonic sum, not a twin-prime estimate. To prove it, fix the two small **genuine** primes $r<s$, $rs>D$. For each such pair $X/(rs)\le p\le2X/(rs)$, and $p\ge X^{0.50010}$. Uniformly in these pairs the prime number theorem gives $\sum_p\log p=X/(rs)+O((X/rs)e^{-c\sqrt{\log X}})$. The total $\sum_{r,s}1/(rs)$ stays bounded at fixed $\delta,t$. Prime harmonic weak convergence on the compact logarithmic box, and the fact that the equality boundaries have zero measure, give the double integral in (D). There is exactly one ordered choice $r<s$, which accounts for the factor $1/2$.

Set $a=\delta/t$. Splitting the integral at $u=t-\delta$ gives the **closed form**

$$
\mathcal I=\frac12\left[\operatorname{Li}_2(1-a)-\operatorname{Li}_2(a)
+\log(1/a)\log\frac1{1-a}\right]
=0.61141861980926243232\ldots.
\tag{E}
$$

The direct integral and the dilogarithm formula agree numerically. Also, imposing the *necessary* local residue $M\equiv2\pmod3$ (so that $N=M+2\not\equiv0\pmod3$) leaves $(\mathcal I/2+o(1))X$ in (D): the large prime $p$ is equidistributed between the two unit classes modulo 3, uniformly on this fixed polynomial range. This checks that the positive sector is not eliminated by the first local obstruction, but **it does not establish any of the required $N$-prime-factor conditions**.

The numerical experiment independently recomputed $F_D(M)$ by enumerating every divisor, comparing (A)–(B) on all squarefree two- and three-prime odd $M$ in $(10^6,1.06\cdot10^6)$: 9,750 rank-two and 7,509 rank-three examples passed. This tests the exact formulas only. A reproducible integral check uses Python 3 with `mpmath`:

```python
import mpmath as mp
mp.mp.dps = 35
t, delta = mp.mpf('0.24995'), mp.mpf('0.05')
a = delta / t
I = (mp.polylog(2, 1-a) - mp.polylog(2, a)
     + mp.log(1/a)*mp.log(1/(1-a))) / 2
J = mp.quad(lambda u: mp.log(t/max(delta,t-u))/u,
            [delta, t-delta, t]) / 2
print(I, J, abs(I-J))
```

**What this discriminates.** The positive rank-three $M$ sector has a nontrivial ordinary one-sided size, and its entire contribution to the actual $R_X$ is a two-site arithmetic correlation involving $p$ and the factorization of $rsp+2$. The constant $\mathcal I$ is in *unpaired* weighted-integer units $X$, whereas $R_X$ is in *normalized paired-prime* units $K_0J_X$: **do not compare $0.6114186$ numerically to the threshold $0.21805$**. Such a comparison would omit the essential $N\in\mathcal A_X$ restriction and its additional prime-counting factor. The next meaningful estimate is a one-sided bound on the shifted-prime count restricted to (C), with the full $G_2(rsp+2)$ weight, together with the positive parts of ranks four through seven and any negative terms retained in the final signed budget. A pure one-site angular estimate, or an unsigned count of (C), cannot supply that estimate.

**Agent availability and verification.** No callable research subagent facility was exposed in the current tool inventory. The identities, PNT derivation and local numeric test were performed in the coordinator session; they are not advertised as independently agent-validated. The original archive and all superseded failed approaches remain unchanged. A fresh arithmetic bound for the actual two-site sum has not been proved.

## Decisive dead ends

- **The original global identity still checks the units.** In the notation here the canonical reduction reads $B_X T_X=B_X-C_{305}+O_A(X/\log^A X)$ for every fixed $A$, with the log-weight convention absorbed in the error. In the equivalent prime-marked sum take $Y=X^{0.0005}$, $p>X^{0.4997}$ a genuine prime divisor of $P+2$, and $m=(P+2)/p$. The unit $m=1$ is precisely a twin. Each admissible $p$ on the same $P+2$ is counted. The historical three-rank discrepancy upper $5.38145$ missed its sufficient threshold $0.18233$ in that calculation's own units. The leading term of the nonnegative composite sum still leaves the additive term that decides the twin count. See Part I, §§305, 308GG and 308LH.
- **A single factor-size box leaves a complement.** On $(u,v,p)$ of sizes $(X^{0.6},X^{0.4},X^{0.525})$, the last convolution coefficient is $(\mu*\mu*\log)(s)=-\mu(s)\log s$ because $s\le X^{0.127}<X^{0.13}$. Transfer of the progression main terms requires the full right-divisor sums, original windows and shared factors. The separate Shiu–Fourier bound is $O(X/(\log Y\log Z))$ on a fixed box, $Z=\exp((\log X)^{0.24})$. Its Fourier product runs over every distinct prime divisor of the cofactor. Summing the boxes requires paying their multiplicity. The auxiliary product $ab$ in this expansion can be composite. See §§306B–C and 308A–B.
- **A selected family leaves its signed complement.** Section 308LH gives disjoint families with negative and positive contributions. A sufficient upper on the full remaining signed mass is still missing. Likewise, separately estimating the distributions of factors on the two sides of the shift leaves the joint test $R_X$ unresolved, as the two angular comparisons above demonstrate.

## Evidence and numerical checks

The proof archive is `twin-prime-research-state.txt`, version **93**, 11,229,257 bytes. Its SHA-256 is `d18ba2e2d406021bdcd1d97abbf56e6fc9c778c6c816933620a39f0b4992e7e9`. It includes the original handoff and the 2,174,688-byte prior research record. The project deductions have internal mathematical and numerical checks. External validation remains outstanding. [Open the proof archive](https://chatgpt.com/library?file_id=libfile_fde3_f-ddcfe9caa94881918a1dcf3e1e4686da_613d791a52808191a35a409b902e2bdb&account_id=personal)

| Where in archive v93 | What to retrieve |
| --- | --- |
| §§308LQ–LR, with LR starting at line 2095 | Fixed-residue transfer, exact divisor split, short-divisor upper, treatment of prime powers |
| §308LS, line 2287, and §308LT, line 2388 | Bound for the omitted ranks, ordinary rank integrals and positive high-rank argument |
| §308LT, lines 2460–2494 | Six-rank signed comparison, parity reweighting and integer recurrence |
| §308LU, lines 2499–2533 | Final physical inequalities, tagged sieve hypotheses and both directions of subtraction |
| §308LU, lines 2535–2653 | Five consecutive Python numerical checks, including the superseded one-score debit, the stronger four-score debit and the final balanced-semiprime saving |

With the archived version in the current directory, the five numerical checks can be replayed on a Mac with Python 3 and `mpmath` available. The final block prints the saving of about $0.006263639307729$, the inclusive lower endpoint $3.048083783260729$, and the signed-sum threshold before rounding $0.218055686260729$. These programs evaluate the constants used after the analytic estimates.

```sh
shasum -a 256 twin-prime-research-state.txt
sed -n '2535,2653p' twin-prime-research-state.txt | python3 -
```

The fixed-residue estimates used in §§308HJ and 308LO are located by theorem number in the archive. The relevant primary sources for the two sieve applications are [Maynard, Theorem 1.1](https://arxiv.org/abs/2006.06572) and [Pascadi, Propositions 4.4 and 5.2, version 2](https://arxiv.org/html/2505.00653v2).
